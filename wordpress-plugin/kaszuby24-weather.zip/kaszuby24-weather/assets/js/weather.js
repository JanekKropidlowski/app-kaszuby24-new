(function(){
	function qs(el, sel){ return el.querySelector(sel); }
	function qsa(el, sel){ return Array.prototype.slice.call(el.querySelectorAll(sel)); }
	function ce(tag, cls){ var el = document.createElement(tag); if (cls) el.className = cls; return el; }
	function fmt(v, unit){ if(v===undefined||v===null||isNaN(v)) return '—'; return String(v) + (unit||''); }

	function ensureLeaflet(cb){
		if (window.L && window.L.map) { cb(); return; }
		var link = document.createElement('link'); link.rel='stylesheet'; link.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(link);
		var s = document.createElement('script'); s.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload=cb; document.body.appendChild(s);
	}

	function renderPage(root, props){
		root.innerHTML = '';
		var controls = ce('div','k24w-controls');
		var btnGeo = ce('button','k24w-btn'); btnGeo.type='button'; btnGeo.textContent='Użyj mojej lokalizacji';
		var sel = ce('select','k24w-select'); var opt0=ce('option'); opt0.value=''; opt0.textContent='Wybierz najbliższą stację'; sel.appendChild(opt0);
		controls.appendChild(btnGeo); controls.appendChild(sel);
		root.appendChild(controls);

		var grid = ce('div', 'k24w-grid');
		root.appendChild(grid);

		var state = {lat:null, lon:null};
		if (props.lat && props.lon){ state.lat = parseFloat(props.lat); state.lon = parseFloat(props.lon); }

		function onCoords(lat, lon){ state.lat=lat; state.lon=lon; populateStations(); loadAll(); updateTitle(); }

		function geolocate(){
			if (!navigator.geolocation) return;
			navigator.geolocation.getCurrentPosition(function(pos){ onCoords(pos.coords.latitude, pos.coords.longitude); }, function(){ /* ignore */ }, {enableHighAccuracy:true, timeout:8000});
		}

		btnGeo.addEventListener('click', function(){ geolocate(); });
		sel.addEventListener('change', function(){ var v=this.value; if(!v) return; try{ var s=JSON.parse(v); onCoords(parseFloat(s.lat), parseFloat(s.lon)); }catch(e){} });

		function updateTitle(){
			try { if (state.lat && state.lon) { document.title = 'Pogoda — ' + state.lat.toFixed(3)+','+state.lon.toFixed(3) + ' | ' + document.title.replace(/^.*?\|\s*/,''); } } catch(e){}
		}

		function card(title){ var c=ce('div','k24w-card'); var h=ce('h3','k24w-title'); h.textContent=title; c.appendChild(h); return c; }

		function populateStations(){ if (!state.lat || !state.lon) return; sel.innerHTML=''; var o=ce('option'); o.value=''; o.textContent='Najbliższe stacje IMGW'; sel.appendChild(o);
			fetch(window.K24W.rest.base + 'stations/nearest?lat='+state.lat+'&lon='+state.lon+'&limit=8')
				.then(r=>r.json()).then(function(list){
					(list||[]).forEach(function(s){ var opt=ce('option'); opt.value=JSON.stringify({lat:s.lat,lon:s.lon}); opt.textContent=(s.name||s.type)+' — '+(s.distance_km? s.distance_km.toFixed(1)+' km':'' ); sel.appendChild(opt); });
				}).catch(function(){});
		}

		function loadAll(){ if (!state.lat || !state.lon) return; grid.innerHTML='';
			var show = String(props.show||'').split(',').reduce(function(a,s){ a[s.trim()]=true; return a; },{});

			// Current
			if (show.current){
				var c = card('Aktualnie'); grid.appendChild(c);
				fetch(window.K24W.rest.base + 'current?lat='+state.lat+'&lon='+state.lon)
					.then(r=>r.json()).then(function(d){
						var row = ce('div','k24w-row');
						var t = d && d.current ? d.current : (d.current_weather||{});
						row.innerHTML = '<div>Temp</div><div><strong>'+fmt(t.temperature_2m || t.temperature, '°C')+'</strong></div>';
						c.appendChild(row);
						var r2 = ce('div','k24w-row'); r2.innerHTML = '<div>Wiatr</div><div>'+fmt(t.wind_speed_10m || t.windspeed, ' m/s')+'</div>'; c.appendChild(r2);
						var r3 = ce('div','k24w-row'); r3.innerHTML = '<div>Ciśnienie</div><div>'+fmt(t.pressure_msl, ' hPa')+'</div>'; c.appendChild(r3);
					}).catch(function(){ c.appendChild(ce('div','k24w-row')).textContent = 'Brak danych'; });
			}

			// Daily forecast + JSON-LD
			if (show.daily){
				var c = card('Prognoza dzienna'); grid.appendChild(c);
				fetch(window.K24W.rest.base + 'forecast?lat='+state.lat+'&lon='+state.lon)
					.then(r=>r.json()).then(function(d){
						if (!d || !d.daily) { c.appendChild(document.createTextNode('Brak danych')); return; }
						var days = d.daily.time || [];
						for (var i=0;i<Math.min(days.length,7);i++){
							var r = ce('div','k24w-row');
							var max = d.daily.temperature_2m_max && d.daily.temperature_2m_max[i];
							var min = d.daily.temperature_2m_min && d.daily.temperature_2m_min[i];
							r.innerHTML = '<div>'+days[i]+'</div><div>'+fmt(min,'°')+' / '+fmt(max,'°')+'</div>';
							c.appendChild(r);
						}
						// JSON-LD WeatherForecast
						try{
							var ld = { '@context':'https://schema.org', '@type':'WeatherForecast', 'name':'Pogoda', 'description':'Prognoza pogody', 'forecast':[] };
							for (var j=0;j<Math.min(days.length,7);j++){
								ld.forecast.push({ '@type':'WeatherForecast', 'validFrom': days[j], 'lowTemperature': d.daily.temperature_2m_min[j], 'highTemperature': d.daily.temperature_2m_max[j] });
							}
							var s = ce('script'); s.type='application/ld+json'; s.textContent = JSON.stringify(ld);
							c.appendChild(s);
						}catch(e){}
					}).catch(function(){ c.appendChild(document.createTextNode('Brak danych')); });
			}

			// Alerts
			if (show.alerts){
				var c = card('Ostrzeżenia IMGW'); c.classList.add('k24w-alert'); grid.appendChild(c);
				fetch(window.K24W.rest.base + 'warnings')
					.then(r=>r.json()).then(function(d){
						var items = [].concat(d.meteo||[], d.hydro||[]);
						if (!items.length){ c.appendChild(document.createTextNode('Brak ostrzeżeń')); return; }
						items.slice(0,6).forEach(function(w){ var r=ce('div','k24w-row'); r.innerHTML='<div>'+ (w.nazwa_zdarzenia||w.zdarzenie||'Ostrzeżenie') +'</div><div class="k24w-badge">'+(w.stopien||w["stopień"]||'1')+'</div>'; c.appendChild(r); });
					}).catch(function(){ c.appendChild(document.createTextNode('Brak danych')); });
			}

			// AQI
			if (show.aqi){
				var c = card('Jakość powietrza'); grid.appendChild(c);
				fetch(window.K24W.rest.base + 'air?lat='+state.lat+'&lon='+state.lon)
					.then(r=>r.json()).then(function(d){
						if (!d || !d.hourly){ c.appendChild(document.createTextNode('Brak danych')); return; }
						var idx = 0;
						var pm10 = d.hourly.pm10 && d.hourly.pm10[idx];
						var pm25 = d.hourly.pm2_5 && d.hourly.pm2_5[idx];
						var row = ce('div','k24w-row'); row.innerHTML = '<div>PM10</div><div>'+fmt(pm10,' µg/m³')+'</div>'; c.appendChild(row);
						var row2 = ce('div','k24w-row'); row2.innerHTML = '<div>PM2.5</div><div>'+fmt(pm25,' µg/m³')+'</div>'; c.appendChild(row2);
					}).catch(function(){ c.appendChild(document.createTextNode('Brak danych')); });
			}

			// Marine
			if (show.marine){
				var c = card('Morze'); grid.appendChild(c);
				fetch(window.K24W.rest.base + 'marine?lat='+state.lat+'&lon='+state.lon)
					.then(r=>r.json()).then(function(d){
						if (!d || !d.hourly) { c.appendChild(document.createTextNode('Brak danych')); return; }
						var idx = 0;
						var wave = d.hourly.wave_height && d.hourly.wave_height[idx];
						var row = ce('div','k24w-row'); row.innerHTML = '<div>Wysokość fali</div><div>'+fmt(wave,' m')+'</div>'; c.appendChild(row);
					}).catch(function(){ c.appendChild(document.createTextNode('Brak danych')); });
			}

			// Radar
			if (show.radar){
				var c = card('Radar opadów'); grid.appendChild(c);
				var mapEl = ce('div'); mapEl.style.height='320px'; mapEl.style.borderRadius='8px'; c.appendChild(mapEl);
				ensureLeaflet(function(){
					var map = L.map(mapEl, { attributionControl: false }).setView([state.lat, state.lon], 7);
					L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 12 }).addTo(map);
					// Try IMGW products list for hints; fallback to RainViewer tiles
					fetch(window.K24W.rest.base + 'radar/products').then(r=>r.json()).then(function(){
						// RainViewer free tiles
						var rv = L.tileLayer('https://tilecache.rainviewer.com/v2/radar/nowcast_0/512/{z}/{x}/{y}/2/1_1.png', { opacity: 0.6 });
						rv.addTo(map);
					}).catch(function(){
						var rv = L.tileLayer('https://tilecache.rainviewer.com/v2/radar/nowcast_0/512/{z}/{x}/{y}/2/1_1.png', { opacity: 0.6 });
						rv.addTo(map);
					});
				});
			}
		}

		if (!state.lat || !state.lon){ geolocate(); }
		if (state.lat && state.lon){ populateStations(); loadAll(); updateTitle(); }
	}

	function renderWidget(root, props){
		root.innerHTML = '';
		var view = props.view || 'current';
		var wrap = ce('div','k24w-card'); root.appendChild(wrap);
		var title = ce('h3','k24w-title'); title.textContent = 'Pogoda'; wrap.appendChild(title);
		var lat = parseFloat(props.lat), lon = parseFloat(props.lon);
		function fail(){ wrap.appendChild(document.createTextNode('Brak danych')); }
		if (!lat || !lon) {
			if (navigator.geolocation){ navigator.geolocation.getCurrentPosition(function(pos){ lat=pos.coords.latitude; lon=pos.coords.longitude; load(); }, fail, {enableHighAccuracy:true, timeout:8000}); } else { fail(); }
		} else { load(); }
		function load(){
			var base = window.K24W.rest.base;
			if (view==='current'){
				fetch(base+'current?lat='+lat+'&lon='+lon).then(r=>r.json()).then(function(d){ var t=d.current||d.current_weather||{}; var r=ce('div','k24w-row'); r.innerHTML='<div>Temp</div><div><strong>'+fmt(t.temperature_2m||t.temperature,'°C')+'</strong></div>'; wrap.appendChild(r); }).catch(fail);
			} else if (view==='daily'){
				fetch(base+'forecast?lat='+lat+'&lon='+lon).then(r=>r.json()).then(function(d){ if(!d.daily){ fail(); return;} var days=d.daily.time||[]; for(var i=0;i<Math.min(days.length,3);i++){ var r=ce('div','k24w-row'); var max=d.daily.temperature_2m_max[i], min=d.daily.temperature_2m_min[i]; r.innerHTML='<div>'+days[i]+'</div><div>'+fmt(min,'°')+' / '+fmt(max,'°')+'</div>'; wrap.appendChild(r);} }).catch(fail);
			} else if (view==='alerts'){
				fetch(base+'warnings').then(r=>r.json()).then(function(d){ var items=[].concat(d.meteo||[], d.hydro||[]); if(!items.length){ fail(); return;} items.slice(0,3).forEach(function(w){ var r=ce('div','k24w-row'); r.innerHTML='<div>'+(w.nazwa_zdarzenia||w.zdarzenie||'Ostrzeżenie')+'</div><div class="k24w-badge">'+(w.stopien||w["stopień"]||'1')+'</div>'; wrap.appendChild(r); }); }).catch(fail);
			} else { fail(); }
		}
	}

	function hydrate(){
		qsa(document, '.k24w-page').forEach(function(root){ try{ var props=JSON.parse(root.getAttribute('data-props')||'{}'); renderPage(root, props); }catch(e){} });
		qsa(document, '.k24w-widget').forEach(function(root){ try{ var props=JSON.parse(root.getAttribute('data-props')||'{}'); renderWidget(root, props); }catch(e){} });
	}
	if (document.readyState === 'complete' || document.readyState === 'interactive') hydrate(); else document.addEventListener('DOMContentLoaded', hydrate);
})();
