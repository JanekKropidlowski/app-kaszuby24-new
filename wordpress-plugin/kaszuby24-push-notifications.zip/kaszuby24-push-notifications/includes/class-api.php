<?php

if (!defined('ABSPATH')) {
    exit;
}

class Kaszuby24_Push_API {
    
    private $database;
    
    public function __construct() {
        $this->database = new Kaszuby24_Push_Database();
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        register_rest_route('kaszuby24/v1', '/register-expo-push-token', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_token'),
            'permission_callback' => '__return_true',
            'args' => array(
                'pushToken' => array(
                    'required' => true,
                    'type' => 'string',
                    'validate_callback' => array($this, 'validate_push_token')
                ),
                'platform' => array(
                    'required' => true,
                    'type' => 'string',
                    'enum' => array('ios', 'android', 'web')
                ),
                'location' => array(
                    'required' => false,
                    'type' => 'string'
                ),
                'locationId' => array(
                    'required' => false,
                    'type' => 'integer'
                ),
                'preferences' => array(
                    'required' => false,
                    'type' => 'object'
                )
            )
        ));
        
        register_rest_route('kaszuby24/v1', '/send-push-notification', array(
            'methods' => 'POST',
            'callback' => array($this, 'send_notification'),
            'permission_callback' => array($this, 'check_admin_permissions'),
            'args' => array(
                'title' => array(
                    'required' => true,
                    'type' => 'string'
                ),
                'body' => array(
                    'required' => true,
                    'type' => 'string'
                ),
                'articleId' => array(
                    'required' => false,
                    'type' => 'integer'
                ),
                'regions' => array(
                    'required' => false,
                    'type' => 'array'
                ),
                'categories' => array(
                    'required' => false,
                    'type' => 'array'
                )
            )
        ));
        
        register_rest_route('kaszuby24/v1', '/push-stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_stats'),
            'permission_callback' => array($this, 'check_admin_permissions')
        ));
        
        register_rest_route('kaszuby24/v1', '/deactivate-token', array(
            'methods' => 'POST',
            'callback' => array($this, 'deactivate_token'),
            'permission_callback' => '__return_true',
            'args' => array(
                'pushToken' => array(
                    'required' => true,
                    'type' => 'string'
                )
            )
        ));
        
        register_rest_route('kaszuby24/v1', '/posts-filtered', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_filtered_posts'),
            'permission_callback' => '__return_true',
            'args' => array(
                'region' => array(
                    'required' => false,
                    'type' => 'integer',
                    'sanitize_callback' => 'absint'
                ),
                'dzial' => array(
                    'required' => false,
                    'type' => 'integer',
                    'sanitize_callback' => 'absint'
                ),
                'page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 1,
                    'sanitize_callback' => 'absint'
                ),
                'per_page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 10,
                    'sanitize_callback' => 'absint'
                )
            )
        ));
    }
    
    public function register_token($request) {
        try {
            $data = array(
                'pushToken' => sanitize_text_field($request['pushToken']),
                'platform' => sanitize_text_field($request['platform']),
                'location' => sanitize_text_field($request['location'] ?? ''),
                'locationId' => intval($request['locationId'] ?? 0),
                'preferences' => $request['preferences'] ?? null
            );
            
            // Validate preferences structure
            if ($data['preferences'] && !$this->validate_preferences($data['preferences'])) {
                return new WP_Error('invalid_preferences', 'Invalid preferences format', array('status' => 400));
            }
            
            $result = $this->database->register_token($data);
            
            if ($result) {
                return new WP_REST_Response(array(
                    'success' => true,
                    'message' => 'Token registered successfully'
                ), 200);
            } else {
                return new WP_Error('registration_failed', 'Failed to register token', array('status' => 500));
            }
            
        } catch (Exception $e) {
            error_log('Push token registration error: ' . $e->getMessage());
            return new WP_Error('server_error', 'Internal server error', array('status' => 500));
        }
    }
    
    public function send_notification($request) {
        try {
            $title = sanitize_text_field($request['title']);
            $body = sanitize_textarea_field($request['body']);
            $article_id = intval($request['articleId'] ?? 0);
            $regions = $request['regions'] ?? array();
            $categories = $request['categories'] ?? array();
            
            // Get target tokens based on preferences
            $tokens = $this->database->get_tokens_by_preferences($regions, $categories);
            
            if (empty($tokens)) {
                return new WP_REST_Response(array(
                    'success' => false,
                    'message' => 'No tokens found for specified criteria'
                ), 200);
            }
            
            // Send notifications via Expo Push service
            $expo_push = new Kaszuby24_Expo_Push();
            $results = $expo_push->send_notifications($tokens, $title, $body, $article_id);
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Notifications sent',
                'sent_count' => $results['sent'],
                'failed_count' => $results['failed'],
                'total_tokens' => count($tokens)
            ), 200);
            
        } catch (Exception $e) {
            error_log('Push notification send error: ' . $e->getMessage());
            return new WP_Error('send_error', 'Failed to send notifications', array('status' => 500));
        }
    }
    
    public function get_stats($request) {
        try {
            $stats = $this->database->get_stats();
            
            return new WP_REST_Response(array(
                'success' => true,
                'stats' => $stats
            ), 200);
            
        } catch (Exception $e) {
            error_log('Push stats error: ' . $e->getMessage());
            return new WP_Error('stats_error', 'Failed to get statistics', array('status' => 500));
        }
    }
    
    public function deactivate_token($request) {
        try {
            $token = sanitize_text_field($request['pushToken']);
            
            $result = $this->database->deactivate_token($token);
            
            if ($result) {
                return new WP_REST_Response(array(
                    'success' => true,
                    'message' => 'Token deactivated successfully'
                ), 200);
            } else {
                return new WP_Error('deactivation_failed', 'Failed to deactivate token', array('status' => 500));
            }
            
        } catch (Exception $e) {
            error_log('Push token deactivation error: ' . $e->getMessage());
            return new WP_Error('server_error', 'Internal server error', array('status' => 500));
        }
    }
    
    public function validate_push_token($param, $request, $key) {
        // Validate Expo push token format
        if (!is_string($param)) {
            return false;
        }
        
        // Expo push tokens start with ExponentPushToken[
        if (strpos($param, 'ExponentPushToken[') === 0) {
            return true;
        }
        
        // Also accept test tokens for development
        if (strpos($param, 'ExpoPushToken[') === 0) {
            return true;
        }
        
        return false;
    }
    
    public function validate_preferences($preferences) {
        if (!is_array($preferences)) {
            return false;
        }
        
        // Check if regions and categories are arrays of integers
        if (isset($preferences['regions']) && !is_array($preferences['regions'])) {
            return false;
        }
        
        if (isset($preferences['categories']) && !is_array($preferences['categories'])) {
            return false;
        }
        
        // Validate that all IDs are integers
        if (isset($preferences['regions'])) {
            foreach ($preferences['regions'] as $region_id) {
                if (!is_int($region_id) && !ctype_digit($region_id)) {
                    return false;
                }
            }
        }
        
        if (isset($preferences['categories'])) {
            foreach ($preferences['categories'] as $cat_id) {
                if (!is_int($cat_id) && !ctype_digit($cat_id)) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    public function check_admin_permissions($request) {
        return current_user_can('manage_options');
    }
    
    public function get_filtered_posts($request) {
        try {
            $region_id = $request->get_param('region');
            $dzial_id = $request->get_param('dzial');
            $page = $request->get_param('page') ?: 1;
            $per_page = $request->get_param('per_page') ?: 10;
            
            // Validate that at least one filter is provided
            if (!$region_id && !$dzial_id) {
                return new WP_Error('missing_filters', 'At least one filter (region or dzial) must be provided', array('status' => 400));
            }
            
            // Build the query arguments
            $args = array(
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => $per_page,
                'paged' => $page,
                'orderby' => 'date',
                'order' => 'DESC',
                'meta_query' => array(),
                'tax_query' => array(
                    'relation' => 'AND'
                )
            );
            
            // Add region filter if provided
            if ($region_id) {
                $args['tax_query'][] = array(
                    'taxonomy' => 'region',
                    'field' => 'term_id',
                    'terms' => $region_id,
                    'operator' => 'IN'
                );
            }
            
            // Add dzial filter if provided
            if ($dzial_id) {
                $args['tax_query'][] = array(
                    'taxonomy' => 'dzial',
                    'field' => 'term_id',
                    'terms' => $dzial_id,
                    'operator' => 'IN'
                );
            }
            
            // Execute the query
            $query = new WP_Query($args);
            
            if ($query->have_posts()) {
                $posts = array();
                
                while ($query->have_posts()) {
                    $query->the_post();
                    
                    // Get post data
                    $post_data = array(
                        'id' => get_the_ID(),
                        'title' => array(
                            'rendered' => get_the_title()
                        ),
                        'excerpt' => array(
                            'rendered' => get_the_excerpt()
                        ),
                        'content' => array(
                            'rendered' => get_the_content()
                        ),
                        'date' => get_the_date('c'),
                        'modified' => get_the_modified_date('c'),
                        'link' => get_permalink(),
                        'slug' => get_post_field('post_name'),
                        'featured_media' => get_post_thumbnail_id(),
                        'featured_media_url' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
                        'author' => get_the_author_meta('ID'),
                        'categories' => wp_get_post_categories(get_the_ID(), array('fields' => 'ids')),
                        'tags' => wp_get_post_tags(get_the_ID(), array('fields' => 'ids')),
                        'meta' => array(
                            'views' => get_post_meta(get_the_ID(), 'views', true),
                            'flickr' => get_post_meta(get_the_ID(), 'flickr', true),
                            'youtube' => get_post_meta(get_the_ID(), 'youtube', true),
                            'foto' => get_post_meta(get_the_ID(), 'foto', true),
                            'zrodlo' => get_post_meta(get_the_ID(), 'zrodlo', true),
                            'zrudlo' => get_post_meta(get_the_ID(), 'zrudlo', true),
                            'galeria' => get_post_meta(get_the_ID(), 'galeria', true),
                            'link' => get_post_meta(get_the_ID(), 'link', true)
                        )
                    );
                    
                    // Get embedded data
                    $post_data['_embedded'] = array(
                        'author' => array(
                            array(
                                'id' => get_the_author_meta('ID'),
                                'name' => get_the_author(),
                                'url' => get_author_posts_url(get_the_author_meta('ID')),
                                'avatar_urls' => array(
                                    '96' => get_avatar_url(get_the_author_meta('ID'), 96),
                                    '24' => get_avatar_url(get_the_author_meta('ID'), 24)
                                )
                            )
                        ),
                        'wp:featuredmedia' => array(),
                        'wp:term' => array()
                    );
                    
                    // Get featured media
                    if (has_post_thumbnail()) {
                        $post_data['_embedded']['wp:featuredmedia'][] = array(
                            'id' => get_post_thumbnail_id(),
                            'source_url' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
                            'media_details' => array(
                                'sizes' => array(
                                    'medium' => array(
                                        'source_url' => get_the_post_thumbnail_url(get_the_ID(), 'medium')
                                    ),
                                    'thumbnail' => array(
                                        'source_url' => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail')
                                    )
                                )
                            )
                        );
                    }
                    
                    // Get terms (categories, tags, regions, dzial)
                    $categories = get_the_category();
                    $tags = get_the_tags();
                    $regions = get_the_terms(get_the_ID(), 'region');
                    $dzial_terms = get_the_terms(get_the_ID(), 'dzial');
                    
                    $all_terms = array();
                    if ($categories) $all_terms = array_merge($all_terms, $categories);
                    if ($tags) $all_terms = array_merge($all_terms, $tags);
                    if ($regions) $all_terms = array_merge($all_terms, $regions);
                    if ($dzial_terms) $all_terms = array_merge($all_terms, $dzial_terms);
                    
                    if ($all_terms) {
                        $terms_data = array();
                        foreach ($all_terms as $term) {
                            $terms_data[] = array(
                                'id' => $term->term_id,
                                'name' => $term->name,
                                'slug' => $term->slug,
                                'taxonomy' => $term->taxonomy
                            );
                        }
                        $post_data['_embedded']['wp:term'][] = $terms_data;
                    }
                    
                    $posts[] = $post_data;
                }
                
                wp_reset_postdata();
                
                return new WP_REST_Response(array(
                    'success' => true,
                    'posts' => $posts,
                    'total_posts' => $query->found_posts,
                    'total_pages' => $query->max_num_pages,
                    'current_page' => $page,
                    'per_page' => $per_page,
                    'filters' => array(
                        'region' => $region_id,
                        'dzial' => $dzial_id
                    )
                ), 200);
                
            } else {
                return new WP_REST_Response(array(
                    'success' => true,
                    'posts' => array(),
                    'total_posts' => 0,
                    'total_pages' => 0,
                    'current_page' => $page,
                    'per_page' => $per_page,
                    'filters' => array(
                        'region' => $region_id,
                        'dzial' => $dzial_id
                    ),
                    'message' => 'No posts found with the specified filters'
                ), 200);
            }
            
        } catch (Exception $e) {
            error_log('Filtered posts error: ' . $e->getMessage());
            return new WP_Error('filter_error', 'Failed to get filtered posts', array('status' => 500));
        }
    }
} 